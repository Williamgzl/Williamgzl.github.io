Thanks for downloading! By downloading this, you are helping people who can't buy or afford the game still join multiplayer servers. 
If you want to support this project, donate at shop.skaiacraft.net

Please join our server: play.skaia.us

To open Minecraft, just doubleclick the 'SkaiaCraft_Launcher_v1.500.jar' file. 
Use as the original launcher except without the need of any paid Minecraft account! 

Prerequisite: Java. You can download that at www.java.com

Launcher Help/Info Email: support@skaia.us